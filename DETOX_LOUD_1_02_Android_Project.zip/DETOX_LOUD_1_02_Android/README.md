# DETOX LOUD 1.02 — Android starter project

## Included
- Dark audio-console interface, live microphone level meter, swipe-up control panel.
- Engine ON/OFF and four presets (Thunder, Gaming, Radio, Clean).
- Master, Bass Body, Voice Clarity and Thunder Drive controls.
- Ten basic DSP switches and a safety limiter that cannot be disabled.
- **Local Monitor is OFF by default.** When OFF, the app does not write processed audio to the phone's AudioTrack. When ON, it plays the processed signal to the phone's selected audio output.
- Java and Kotlin JVM targets both set to 17.
- Discord button opens the installed Discord app or official login page.

## Important limitations
This is an audio-processing demo, not a Discord microphone driver. On ordinary Android, a third-party app cannot replace Discord's microphone input or inject its processed microphone stream into a Discord voice channel. Local Monitor OFF only stops local playback; it does **not** route audio to VC members. The Discord button opens Discord but does not implement OAuth account linking. A real OAuth integration needs a registered Discord application, redirect URI, and secure backend.

## Build
Open this folder as a project in Android Studio / a compatible Android Gradle environment. Use JDK 17, Android SDK Platform 35, and Gradle 8.9 or a compatible Gradle 8.x version. Run `assembleDebug`. The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- Microphone permission is required.
- Audio routing and latency vary by phone.
- Use a comfortable volume; headphones help reduce acoustic feedback when Local Monitor is enabled.
- This starter project has not been tested on every device and is not a Play Store release.
