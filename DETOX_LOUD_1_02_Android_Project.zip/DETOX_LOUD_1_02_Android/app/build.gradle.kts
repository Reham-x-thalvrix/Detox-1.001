plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.detoxloud.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.detoxloud.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 102
        versionName = "1.02"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
