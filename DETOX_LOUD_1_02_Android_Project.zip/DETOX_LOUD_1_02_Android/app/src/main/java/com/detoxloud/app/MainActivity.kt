package com.detoxloud.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.*
import android.net.Uri
import android.os.Bundle
import android.os.Process
import android.view.*
import android.widget.*
import kotlin.math.*
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 5, 9)
    private val panel = Color.rgb(18, 18, 29)
    private val purple = Color.rgb(157, 124, 255)
    private val white = Color.rgb(242, 242, 250)
    private val muted = Color.rgb(145, 145, 165)
    private var engine: DetoxEngine? = null
    private var isOn = false
    private var monitorEnabled = false
    private lateinit var status: TextView
    private lateinit var power: Button
    private lateinit var meter: MeterView
    private lateinit var sheet: LinearLayout
    private lateinit var handle: TextView
    private var sheetExpanded = false
    private var sheetHeight = 0
    private var gain = 1.18f
    private var bass = .28f
    private var clarity = .30f
    private var drive = .08f
    private val features = linkedMapOf(
        "Noise Gate" to true, "Compressor" to true, "De-Esser" to true,
        "Bass Body" to true, "Voice Clarity" to true, "Exciter" to true,
        "Echo" to false, "Reverb" to false, "Auto Gain" to true, "Safety Limiter" to true
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 11)
        }
    }

    private fun shape(color: Int, radius: Float = 20f) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
    }
    private fun txt(s: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
    private fun params(w: Int = -1, h: Int = -2, weight: Float = 0f) =
        LinearLayout.LayoutParams(w, h, weight)

    private fun buildScreen() {
        val root = FrameLayout(this).apply { setBackgroundColor(bg) }
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 22, 20, 12)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = ImageView(this).apply {
            setBackground(shape(Color.BLACK, 16f)); scaleType = ImageView.ScaleType.CENTER_CROP
        }
        header.addView(logo, LinearLayout.LayoutParams(68, 68))
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(12, 0, 0, 0)
        }
        brand.addView(txt("DETOX LOUD", 21f, white, true))
        brand.addView(txt("VERSION 1.02  •  AUDIO CONSOLE", 9f, purple, true))
        header.addView(brand, params(0, -2, 1f))
        val discord = Button(this).apply {
            text = "OPEN DISCORD"; textSize = 9f; setTextColor(white)
            background = shape(Color.rgb(76, 86, 220), 14f)
            setOnClickListener { openDiscord() }
        }
        header.addView(discord, LinearLayout.LayoutParams(94, 44))
        main.addView(header)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(16, 18, 16, 16)
            background = shape(panel, 24f)
        }
        status = txt("● ENGINE OFF  •  NORMAL MODE", 12f, muted, true)
        hero.addView(status)
        meter = MeterView(this)
        val mp = LinearLayout.LayoutParams(-1, 86); mp.topMargin = 12
        hero.addView(meter, mp)
        power = Button(this).apply {
            text = "⚡  TURN ON"; textSize = 15f; setTextColor(Color.BLACK)
            background = shape(purple, 18f)
            setOnClickListener { if (isOn) stopEngine() else startEngine() }
        }
        val pp = LinearLayout.LayoutParams(-1, 54); pp.topMargin = 14
        hero.addView(power, pp)
        val hp = LinearLayout.LayoutParams(-1, -2); hp.topMargin = 22
        main.addView(hero, hp)

        val hint = txt("Swipe up from the bottom handle to open the control menu", 10f, muted)
        hint.gravity = Gravity.CENTER
        val hHint = LinearLayout.LayoutParams(-1, -2); hHint.topMargin = 12
        main.addView(hint, hHint)
        root.addView(main, FrameLayout.LayoutParams(-1, -1))

        sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 10, 16, 18)
            background = GradientDrawable().apply {
                setColor(Color.rgb(15, 15, 25))
                cornerRadii = floatArrayOf(26f,26f,26f,26f,0f,0f,0f,0f)
                setStroke(1, Color.rgb(54, 48, 84))
            }
        }
        handle = txt("━━━━━━━━━━   MENU   ━━━━━━━━━━", 12f, purple, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, 5, 0, 14)
            setOnTouchListener { _, ev -> handleSwipe(ev); true }
        }
        sheet.addView(handle)
        val scroller = ScrollView(this)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        controls.addView(txt("QUICK PRESETS", 11f, muted, true).apply { setPadding(2, 6, 0, 8) })
        val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("THUNDER", "GAMING", "RADIO", "CLEAN").forEachIndexed { i, name ->
            val b = Button(this).apply {
                text = name; textSize = 9f; setTextColor(white); background = shape(Color.rgb(37,32,58), 12f)
                setOnClickListener { applyPreset(i) }
            }
            val lp = LinearLayout.LayoutParams(0, 42, 1f); lp.setMargins(3, 0, 3, 8)
            presetRow.addView(b, lp)
        }
        controls.addView(presetRow)
        controls.addView(txt("LOUD CONTROLS", 11f, muted, true).apply { setPadding(2, 8, 0, 5) })
        addSlider(controls, "MASTER OUTPUT", 68, "×%.2f") { gain = .5f + it/100f; updateEngine() }
        addSlider(controls, "BASS BODY", 28, "%d%%") { bass = it/100f; updateEngine() }
        addSlider(controls, "VOICE CLARITY", 30, "%d%%") { clarity = it/100f; updateEngine() }
        addSlider(controls, "THUNDER DRIVE", 8, "%d%%") { drive = it/100f; updateEngine() }
        controls.addView(txt("LOCAL MONITOR", 11f, muted, true).apply { setPadding(2, 10, 0, 4) })
        val monitorSwitch = CheckBox(this).apply {
            text = "Play processed audio on this phone (OFF by default)"
            setTextColor(white)
            buttonTintList = android.content.res.ColorStateList.valueOf(purple)
            isChecked = false
            setOnCheckedChangeListener { _, checked ->
                monitorEnabled = checked
                engine?.setMonitor(checked)
                Toast.makeText(this@MainActivity, if (checked) "Local monitor ON" else "Local monitor OFF", Toast.LENGTH_SHORT).show()
            }
        }
        controls.addView(monitorSwitch, params())
        controls.addView(txt("10 AUDIO FEATURES", 11f, muted, true).apply { setPadding(2, 10, 0, 6) })
        features.keys.forEach { name ->
            val cb = CheckBox(this).apply {
                text = name
                setTextColor(white)
                buttonTintList = android.content.res.ColorStateList.valueOf(purple)
                isChecked = features[name] == true
                if (name == "Safety Limiter") {
                    isChecked = true; isEnabled = false
                }
                setOnCheckedChangeListener { _, checked ->
                    features[name] = if (name == "Safety Limiter") true else checked
                    updateEngine()
                }
            }
            controls.addView(cb, params())
        }
        controls.addView(txt(
            "ENGINE ON: processes microphone audio. LOCAL MONITOR OFF: does not play the processed signal on this phone. " +
            "This does not send audio into Discord. Standard Android apps cannot replace Discord's microphone input.",
            10f, muted
        ).apply { setPadding(3, 12, 3, 18) })
        scroller.addView(controls)
        sheet.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        val sh = (resources.displayMetrics.heightPixels * .74f).toInt()
        sheetHeight = sh
        val sheetLp = FrameLayout.LayoutParams(-1, sh, Gravity.BOTTOM)
        root.addView(sheet, sheetLp)
        sheet.translationY = (sh - dp(78)).toFloat()
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (sheetHeight > 0 && !sheetExpanded) sheet.translationY = (sheetHeight - dp(78)).toFloat()
        }
        setContentView(root)
        loadLogo(logo)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun handleSwipe(ev: MotionEvent): Boolean {
        when (ev.action) {
            MotionEvent.ACTION_DOWN -> { downY = ev.rawY; return true }
            MotionEvent.ACTION_UP -> {
                val delta = ev.rawY - downY
                if (delta < -28) expandSheet()
                else if (delta > 28) collapseSheet()
                else if (sheetExpanded) collapseSheet() else expandSheet()
                return true
            }
        }
        return true
    }
    private var downY = 0f
    private fun expandSheet() {
        sheetExpanded = true
        sheet.animate().translationY(0f).setDuration(220).start()
        handle.text = "━━━━━━━━━━   CLOSE MENU   ━━━━━━━━━━"
    }
    private fun collapseSheet() {
        sheetExpanded = false
        sheet.animate().translationY((sheetHeight - dp(78)).toFloat()).setDuration(220).start()
        handle.text = "━━━━━━━━━━   MENU   ━━━━━━━━━━"
    }

    private fun loadLogo(view: ImageView) {
        thread {
            try {
                val conn = URL("https://i.postimg.cc/rFnbGDT8/20261101-225549.jpg").openConnection() as HttpURLConnection
                conn.connectTimeout = 4500; conn.readTimeout = 4500
                conn.inputStream.use { stream ->
                    val bmp = BitmapFactory.decodeStream(stream)
                    runOnUiThread { view.setImageBitmap(bmp) }
                }
                conn.disconnect()
            } catch (_: Exception) { runOnUiThread { view.setImageDrawable(null) } }
        }
    }

    private fun openDiscord() {
        val launch = packageManager.getLaunchIntentForPackage("com.discord")
        try {
            if (launch != null) startActivity(launch)
            else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://discord.com/login")))
        } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://discord.com/login")))
        }
    }

    private fun addSlider(parent: LinearLayout, title: String, initial: Int, format: String, changed: (Int)->Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(2, 5, 2, 4) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(txt(title, 10f, muted, true), params(0, -2, 1f))
        val value = txt("", 10f, purple, true)
        row.addView(value)
        box.addView(row)
        val bar = SeekBar(this).apply {
            max = 100; progress = initial
            progressTintList = android.content.res.ColorStateList.valueOf(purple)
            thumbTintList = android.content.res.ColorStateList.valueOf(white)
        }
        fun show(v: Int) { value.text = if (format.contains("×")) String.format(format, .5f + v/100f) else String.format(format, v) }
        show(initial)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { show(p); if (fromUser) changed(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(bar); parent.addView(box)
    }

    private fun applyPreset(i: Int) {
        when (i) {
            0 -> { gain=1.28f; bass=.34f; clarity=.34f; drive=.12f; features["Echo"]=false; features["Reverb"]=true }
            1 -> { gain=1.18f; bass=.18f; clarity=.48f; drive=.10f; features["Echo"]=false; features["Reverb"]=false }
            2 -> { gain=1.08f; bass=.12f; clarity=.20f; drive=.06f; features["Echo"]=true; features["Reverb"]=true }
            else -> { gain=1f; bass=.12f; clarity=.20f; drive=0f; features["Echo"]=false; features["Reverb"]=false }
        }
        updateEngine()
        Toast.makeText(this, listOf("THUNDER","GAMING","RADIO","CLEAN")[i] + " preset applied", Toast.LENGTH_SHORT).show()
    }

    private fun updateEngine() {
        engine?.update(gain, bass, clarity, drive, features.toMap())
    }

    private fun startEngine() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 11); return
        }
        try {
            engine = DetoxEngine({ running, level ->
                runOnUiThread {
                    isOn = running
                    status.text = if (running) "● DETOX ENGINE ON  •  LIVE INPUT" else "● ENGINE OFF  •  NORMAL MODE"
                    status.setTextColor(if (running) Color.rgb(95, 220, 155) else muted)
                    power.text = if (running) "■  TURN OFF" else "⚡  TURN ON"
                    meter.setLevel(level)
                }
            }).also { it.start(gain, bass, clarity, drive, features.toMap(), monitorEnabled) }
        } catch (e: Exception) {
            Toast.makeText(this, "Audio error: ${e.message ?: "Unable to start"}", Toast.LENGTH_LONG).show()
            stopEngine()
        }
    }

    private fun stopEngine() {
        engine?.stop(); engine = null; isOn = false
        status.text = "● ENGINE OFF  •  NORMAL MODE"
        status.setTextColor(muted)
        power.text = "⚡  TURN ON"
        meter.setLevel(0f)
    }

    override fun onDestroy() { stopEngine(); super.onDestroy() }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 11 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED)
            Toast.makeText(this, "Microphone permission granted", Toast.LENGTH_SHORT).show()
    }
}

private class MeterView(context: android.content.Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    @Volatile private var level = 0f
    fun setLevel(v: Float) { level = v.coerceIn(0f, 1f); postInvalidateOnAnimation() }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bars = 42
        val gap = width * .008f
        val bw = (width - gap * (bars - 1)) / bars
        val active = (level * bars).roundToInt()
        for (i in 0 until bars) {
            val x = i * (bw + gap)
            val h = height * (.20f + .80f * ((i % 7 + 1) / 7f))
            paint.color = when {
                i >= active -> Color.rgb(42, 39, 58)
                i > bars * .82 -> Color.rgb(255, 90, 100)
                i > bars * .62 -> Color.rgb(255, 190, 75)
                else -> Color.rgb(157, 124, 255)
            }
            canvas.drawRoundRect(x, height-h, x+bw, height.toFloat(), bw/2, bw/2, paint)
        }
        paint.color = Color.rgb(180, 174, 210); paint.textSize = 10f
        canvas.drawText("INPUT LEVEL", 2f, 12f, paint)
        canvas.drawText("${(level*100).roundToInt()}%", width-45f, 12f, paint)
    }
}

private class DetoxEngine(private val state: (Boolean, Float)->Unit) {
    @Volatile private var running = false
    @Volatile private var master = 1.18f
    @Volatile private var bass = .28f
    @Volatile private var clarity = .3f
    @Volatile private var drive = .08f
    @Volatile private var monitorEnabled = false
    @Volatile private var flags: Map<String, Boolean> = emptyMap()
    private var worker: Thread? = null
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private val rate = 48000

    fun update(g: Float, b: Float, c: Float, d: Float, f: Map<String, Boolean>) {
        master=g.coerceIn(.5f,1.5f); bass=b.coerceIn(0f,1f)
        clarity=c.coerceIn(0f,1f); drive=d.coerceIn(0f,1f); flags=f
    }

    fun setMonitor(enabled: Boolean) { monitorEnabled = enabled }

    fun start(g: Float, b: Float, c: Float, d: Float, f: Map<String, Boolean>, monitor: Boolean) {
        update(g,b,c,d,f)
        monitorEnabled = monitor
        val minIn = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val minOut = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minIn <= 0 || minOut <= 0) throw IllegalStateException("Audio format unsupported")
        val size = max(minIn, minOut).coerceAtLeast(4096) * 2
        recorder = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, rate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
        if (recorder?.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("Microphone unavailable")
        player = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(size).setTransferMode(AudioTrack.MODE_STREAM).build()
        running=true
        recorder!!.startRecording(); player!!.play(); state(true, 0f)
        worker = Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            val input = ShortArray(size/2)
            val echoBuf = DoubleArray(rate/3)
            val revBuf = DoubleArray(rate/12)
            var echoPos=0; var revPos=0
            var bassState=0.0; var prev=0.0; var agc=1.0
            while (running) {
                val n = recorder?.read(input,0,input.size) ?: break
                if (n <= 0) continue
                val out = ShortArray(n)
                val g=master.toDouble(); val ba=bass.toDouble(); val cl=clarity.toDouble(); val dr=drive.toDouble()
                val f=flags
                var sum=0.0
                for (i in 0 until n) {
                    var x=input[i].toDouble()/32768.0
                    val absx=abs(x)
                    if (f["Noise Gate"] == true && absx < .012) x=0.0
                    bassState += .035 * (x-bassState)
                    val high=x-prev; prev=x
                    var y=x
                    if (f["Bass Body"] == true) y += bassState*ba*.65
                    if (f["Voice Clarity"] == true) y += high*cl*.18
                    if (f["De-Esser"] == true && high > .16) y -= (high-.16)*.30
                    if (f["Compressor"] == true) {
                        val a=abs(y)
                        if (a > .32) y = sign(y) * (.32 + (a-.32)*.42)
                    }
                    y *= g
                    if (f["Auto Gain"] == true) {
                        val target = (0.22 / max(.035, abs(y))).coerceIn(.75, 1.35)
                        agc += (target-agc)*.0008
                        y *= agc
                    }
                    if (f["Exciter"] == true && dr > .001) y = tanh(y*(1.0+dr*5.0))
                    if (f["Echo"] == true) {
                        val delayed=echoBuf[echoPos]
                        echoBuf[echoPos]=y + delayed*.24
                        echoPos=(echoPos+1)%echoBuf.size
                        y += delayed*.18
                    }
                    if (f["Reverb"] == true) {
                        val delayed=revBuf[revPos]
                        revBuf[revPos]=y + delayed*.28
                        revPos=(revPos+1)%revBuf.size
                        y += delayed*.14
                    }
                    if (f["Safety Limiter"] != false) y = tanh(y*1.45)/tanh(1.45)
                    y=y.coerceIn(-1.0,1.0)
                    sum += y*y
                    out[i]=(y*32767.0).roundToInt().coerceIn(-32768,32767).toShort()
                }
                if (monitorEnabled) player?.write(out,0,n,AudioTrack.WRITE_BLOCKING)
                state(true, sqrt(sum/max(1,n)).toFloat().coerceIn(0f,1f))
            }
        }.apply { name="DetoxLoudDSP"; start() }
    }

    fun stop() {
        running=false
        try { recorder?.stop() } catch (_: Exception) {}
        try { player?.pause(); player?.flush(); player?.stop() } catch (_: Exception) {}
        try { worker?.join(500) } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        recorder=null; player=null; worker=null
        state(false,0f)
    }
}
